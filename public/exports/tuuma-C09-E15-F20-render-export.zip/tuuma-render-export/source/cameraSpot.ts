export function cameraSpot(design: Design, id: string): [
    number,
    number,
    number
] {
    const room = design.rooms.find(r => r.id === id)!;
    const stairs = stairProfile(design);
    if (room.code === "PORRAS" && stairs) return [room.x / 1000 + stairs.start / 2, ((room.level ?? 1) - 1) * (design.height / 1000 + .22) + 1.6, room.z / 1000 + ((room.level ?? 1) === 1 ? stairs.nearLane : stairs.farLane)];
    const options = [.5, .65, .35, .8, .2].flatMap(x => [.5, .7, .3, .85].map(z => ({ x: room.x + room.w * x, z: room.z + room.d * z })));
    const spot = options.find(p => !design.fittings.some(f => f.room === id && f.kind !== "rug" && p.x > f.x - 200 && p.x < f.x + f.w + 200 && p.z > f.z - 200 && p.z < f.z + f.d + 200)) ?? options[0];
    const storeyOffset = ((room.level ?? 1) - 1) * (design.height / 1000 + .22);
    return [spot.x / 1000, storeyOffset + 1.6, spot.z / 1000];
}
